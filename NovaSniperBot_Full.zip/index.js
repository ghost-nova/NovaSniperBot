
require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');

const token = process.env.BOT_TOKEN;
if (!token) {
    console.error('BOT_TOKEN not set in environment variables.');
    process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });

bot.onText(/\/start/, (msg) => {
    bot.sendMessage(msg.chat.id, '🟢 Nova + Ghost is live and listening. Type /radar to scan.');
});

bot.onText(/\/radar/, (msg) => {
    bot.sendMessage(msg.chat.id, '📡 Radar pinged. Scanning for meme coin launches...');
});

bot.onText(/\/sniper/, (msg) => {
    bot.sendMessage(msg.chat.id, '🎯 Sniper mode is primed. Waiting for wallet trigger...');
});

bot.on("message", (msg) => {
    if (!msg.text.startsWith('/')) {
        bot.sendMessage(msg.chat.id, 'Command not recognized. Try /start or /radar.');
    }
});

console.log('NovaSniperBot is running...');
